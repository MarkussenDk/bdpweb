--//
CREATE VIEW `car_models_2_v` AS 
select `cma`.`car_make_name` AS `car_make_name`
,`cmo`.`car_model_id` AS `car_model_id`
,`cmo`.`car_model_name` AS `car_model_name` 
from (`car_models` `cmo` 
join `car_makes` `cma` on((`cmo`.`car_make_id` = `cma`.`car_make_id`)));

--//@UNDO
drop view `car_models_3_v`;
--/ 