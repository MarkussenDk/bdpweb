SELECT * FROM `bdp_dev`.`sps_spp_cm2spp_cmo_v`;

use bdp_dev;

create view sps_spp_cm2spp_cmo_v as 
select `sps`.`supplier_name` AS `supplier_name`,`cmo`.`car_make_name` AS `car_make_name`
,`cmo`.`car_model_name` AS `car_model_name`,`cmo`.`car_model_id` AS `car_model_id`
,`spp`.`spare_part_price_id` AS `spare_part_price_id`,`spp`.`name` AS `name`
,`spp`.`description` AS `description`,`spp`.`spare_part_url` AS `spare_part_url`
,`spp`.`spare_part_image_url` AS `spare_part_image_url`,`spp`.`spare_part_category_id` AS `spare_part_category_id`
,`spp`.`spare_part_category_free_text` AS `spare_part_category_free_text`,`spp`.`part_placement` AS `part_placement`
,`spp`.`part_placement_left_right` AS `part_placement_left_right`,`spp`.`part_placement_front_back` AS `part_placement_front_back`
,`spp`.`supplier_part_number` AS `supplier_part_number`,`spp`.`original_part_number` AS `original_part_number`
,`spp`.`price_inc_vat` AS `price_inc_vat`,`spp`.`producer_make_name` AS `producer_make_name`
,`spp`.`producer_part_number` AS `producer_part_number`,`spp`.`spare_part_supplier_id` AS `spare_part_supplier_id`
,`cm2spp`.`year_from` AS `year_from`,`cm2spp`.`month_from` AS `month_from`,`cm2spp`.`year_to` AS `year_to`,`cm2spp`.`month_to` AS `month_to`
,`cm2spp`.`chassis_no_from` AS `chassis_no_from`,`cm2spp`.`chassis_no_to` AS `chassis_no_to` 
from (((`bdp_dev`.`spare_part_prices` `spp` 
left join `spare_part_suppliers` `sps` on((`sps`.`spare_part_supplier_id` = `spp`.`spare_part_supplier_id`))) 
left join `car_models_to_spare_part_prices` `cm2spp` on((`spp`.`spare_part_price_id` = `cm2spp`.`spare_part_price_id`))) 
left join `car_models_v` `cmo` on((`cm2spp`.`car_model_id` = `cmo`.`car_model_id`)))