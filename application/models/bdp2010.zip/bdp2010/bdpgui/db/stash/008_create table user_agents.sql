use bdp_dev;
CREATE  TABLE `user_agents` (

  `user_agent_id` INT NOT NULL AUTO_INCREMENT ,

  `user_agent_info` VARCHAR(500) NULL ,
  
  `cookie_guid` VARCHAR(45) NULL ,

  `created` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ,

  `ip_addr_first_visit` VARCHAR(45) NULL ,

  `is_bot` BINARY NULL ,

  `end_user_id` VARCHAR(500) NULL ,

  `internal_note` VARCHAR(1000) NULL ,

  `next_user_greting` VARCHAR(1000) NULL ,
 
  `allow_remember_user_name` BINARY NULL ,

  `allow_automatic_login` BINARY NULL ,


  PRIMARY KEY (`user_agent_id`) ,

  UNIQUE INDEX `cookie_guid_UNIQUE` (`cookie_guid` ASC) );

drop table `user_agents`;