-- Fragment begins: 2 --
INSERT INTO changelog (change_number, delta_set, start_dt, applied_by, description) VALUES (2, 'Main', NOW(), 'dbdeploy', '002_create_view_car_models_v.sql');
﻿--//
CREATE VIEW `car_models_v` AS 
select `cma`.`car_make_name` AS `car_make_name`
,`cmo`.`car_model_id` AS `car_model_id`
,`cmo`.`car_model_name` AS `car_model_name` 
from (`car_models` `cmo` 
join `car_makes` `cma` on((`cmo`.`car_make_id` = `cma`.`car_make_id`)));


UPDATE changelog SET complete_dt = NOW() WHERE change_number = 2 AND delta_set = 'Main';
-- Fragment ends: 2 --
