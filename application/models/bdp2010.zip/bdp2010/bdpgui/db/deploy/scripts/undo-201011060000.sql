REATE VIEW `car_models_v` AS 
select `cma`.`car_make_name` AS `car_make_name`
,`cmo`.`car_model_id` AS `car_model_id`
,`cmo`.`car_model_name` AS `car_model_name` 
from (`car_models` `cmo` 
join `car_makes` `cma` on((`cmo`.`car_make_id` = `cma`.`car_make_id`)));
--//@UNDO
drop view `car_models_v`;
--//DELETE FROM changelog WHERE change_number = 2 AND delta_set = 'Main';
-- Fragment ends: 2 --
REATE VIEW `car_makes_v` AS 
select `car_makes`.`car_make_id` AS `car_make_id`
,`car_makes`.`car_make_name` AS `car_make_name` from `car_makes` 
where (`car_makes`.`state` in ('Offentlig','Foreslag')) 
order by `car_makes`.`car_make_name`

;

--//@UNDO
drop view `some_car_makes_v`
;
--//DELETE FROM changelog WHERE change_number = 1 AND delta_set = 'Main';
-- Fragment ends: 1 --
