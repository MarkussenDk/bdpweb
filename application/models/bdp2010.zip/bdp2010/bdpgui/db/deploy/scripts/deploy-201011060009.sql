-- Fragment begins: 4 --
INSERT INTO changelog (change_number, delta_set, start_dt, applied_by, description) VALUES (4, 'Main', NOW(), 'dbdeploy', '004_create_view_car_makes_v.sql');
﻿--//
CREATE VIEW `car_makes_v` AS 
select `car_makes`.`car_make_id` AS `car_make_id`
,`car_makes`.`car_make_name` AS `car_make_name` from `car_makes` 
where (`car_makes`.`state` in ('Offentlig','Foreslag')) 
order by `car_makes`.`car_make_name`

;

UPDATE changelog SET complete_dt = NOW() WHERE change_number = 4 AND delta_set = 'Main';
-- Fragment ends: 4 --
