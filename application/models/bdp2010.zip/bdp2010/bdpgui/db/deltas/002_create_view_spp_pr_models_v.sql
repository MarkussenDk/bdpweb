select * from sps_spp_cm2spp_cmo_v p;

create or replace view spp_pr_models_v as 
select p.car_make_name, p.car_model_id, p.car_model_name, count(p.spare_part_price_id) prices  
from sps_spp_cm2spp_cmo_v p
group by 1,2,3
order by 1,2;

select * from spp_pr_models_v;