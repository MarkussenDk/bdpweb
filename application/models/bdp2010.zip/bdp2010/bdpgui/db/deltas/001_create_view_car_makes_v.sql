--//

CREATE VIEW `car_makes_v` AS 
select `car_makes`.`car_make_id` AS `car_make_id`
,`car_makes`.`car_make_name` AS `car_make_name` from `car_makes` 
where (`car_makes`.`state` in ('Offentlig','Foreslag')) 
order by `car_makes`.`car_make_name`
;


--//@UNDO

drop view `some_car_makes_v`
;
--//