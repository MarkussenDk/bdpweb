-- phpMyAdmin SQL Dump
-- version 3.3.3
-- http://www.phpmyadmin.net
--
-- Vært: localhost
-- Genereringstid: 05. 11 2010 kl. 22:10:23
-- Serverversion: 5.1.47
-- PHP-version: 5.2.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bdp_test`
--
USE `bdp_test`;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `car_makes`
--

CREATE TABLE IF NOT EXISTS `car_makes` (
  `car_make_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `car_make_name` varchar(255) COLLATE utf8_danish_ci NOT NULL,
  `car_make_main_id` int(10) unsigned DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(255) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `state` varchar(40) CHARACTER SET utf8  COLLATE utf8_danish_ci NOT NULL,
  `updated` datetime DEFAULT NULL,
  `updated_by` varchar(40) CHARACTER SET utf8  COLLATE utf8_danish_ci NOT NULL,
  `state_enum` enum('Klade','Forslag','Offentlig','Alternativ','Slettet') CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT 'Klade',
  PRIMARY KEY (`car_make_id`),
  UNIQUE KEY `car_make_name` (`car_make_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci AUTO_INCREMENT=101 ;

-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `car_makes_v`
--
CREATE TABLE IF NOT EXISTS `car_makes_v` (
`car_make_id` int(10) unsigned
,`car_make_name` varchar(255)
);
-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `car_model_v`
--
CREATE TABLE IF NOT EXISTS `car_model_v` (
`car_make_name` varchar(255)
,`car_model_id` int(10) unsigned
,`car_make_id` int(10) unsigned
,`car_model_name` varchar(255)
,`car_model_main_id` int(10) unsigned
,`created` datetime
,`created_by` varchar(255)
,`updated` timestamp
,`updated_by` varchar(255)
,`state` varchar(40)
,`state_enum` enum('Klade','Forslag','Offentlig','Alternativ','Slettet')
);
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `car_models`
--

CREATE TABLE IF NOT EXISTS `car_models` (
  `car_model_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `car_make_id` int(10) unsigned NOT NULL COMMENT 'FK to car_makes',
  `car_model_name` varchar(255) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eg. V40 or Golf',
  `car_model_main_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to fx 1.8 or similar',
  `created` datetime NOT NULL,
  `created_by` varchar(255) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(255) CHARACTER SET utf8  COLLATE utf8_danish_ci NOT NULL,
  `state` varchar(40) CHARACTER SET utf8  NOT NULL DEFAULT 'Foreslag',
  `state_enum` enum('Klade','Forslag','Offentlig','Alternativ','Slettet') CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  PRIMARY KEY (`car_model_id`),
  KEY `car_make_id` (`car_make_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci AUTO_INCREMENT=1155 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `car_models_to_spare_part_prices`
--

CREATE TABLE IF NOT EXISTS `car_models_to_spare_part_prices` (
  `car_model_id` int(10) unsigned NOT NULL,
  `spare_part_price_id` int(10) unsigned NOT NULL,
  `year_from` int(4) unsigned DEFAULT NULL,
  `month_from` int(11) DEFAULT NULL,
  `year_to` int(4) unsigned DEFAULT NULL,
  `month_to` int(11) DEFAULT NULL,
  `chassis_no_from` varchar(17) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `chassis_no_to` varchar(17) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` varchar(255) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `xml_http_request_id` int(10) DEFAULT NULL,
  `price_parser_run_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`car_model_id`,`spare_part_price_id`),
  KEY `spare_part_price_id` (`spare_part_price_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;

-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `car_models_v`
--
CREATE TABLE IF NOT EXISTS `car_models_v` (
`car_make_name` varchar(255)
,`car_model_id` int(10) unsigned
,`car_model_name` varchar(255)
);
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `changelog`
--

CREATE TABLE IF NOT EXISTS `changelog` (
  `change_number` bigint(20) NOT NULL,
  `delta_set` varchar(10) COLLATE utf8_danish_ci NOT NULL,
  `start_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `complete_dt` timestamp NULL DEFAULT NULL,
  `applied_by` varchar(100) COLLATE utf8_danish_ci NOT NULL,
  `description` varchar(500) COLLATE utf8_danish_ci NOT NULL,
  PRIMARY KEY (`change_number`,`delta_set`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `delete_candidates`
--

CREATE TABLE IF NOT EXISTS `delete_candidates` (
  `spare_part_price_id` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `doublicate_spp`
--

CREATE TABLE IF NOT EXISTS `doublicate_spp` (
  `spare_part_supplier_id` int(10) unsigned NOT NULL COMMENT 'Reference to the Store',
  `supplier_part_number` varchar(50) COLLATE utf8_danish_ci DEFAULT NULL,
  `count` bigint(21) NOT NULL DEFAULT '0',
  `min` int(10) unsigned DEFAULT NULL,
  `max` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `doublicate_spp_1`
--

CREATE TABLE IF NOT EXISTS `doublicate_spp_1` (
  `spare_part_supplier_id` int(10) unsigned NOT NULL COMMENT 'Reference to the Store',
  `supplier_part_number` varchar(50) COLLATE utf8_danish_ci DEFAULT NULL,
  `count` bigint(21) NOT NULL DEFAULT '0',
  `min` int(10) unsigned DEFAULT NULL,
  `max` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;

-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `info_spp_price_days_stat_v`
--
CREATE TABLE IF NOT EXISTS `info_spp_price_days_stat_v` (
`supplier_name` varchar(255)
,`price_count` bigint(21)
,`spare_part_supplier_id` int(10) unsigned
,`updated_date` date
);
-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `info_spp_price_stat_v`
--
CREATE TABLE IF NOT EXISTS `info_spp_price_stat_v` (
`supplier_name` varchar(255)
,`price_count` bigint(21)
,`spare_part_supplier_id` int(10) unsigned
,`oldest` timestamp
,`newest` timestamp
);
-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `info_spp_view_days_stat_v`
--
CREATE TABLE IF NOT EXISTS `info_spp_view_days_stat_v` (
`supplier_name` varchar(255)
,`price_count` bigint(21)
,`car_makes` bigint(21)
,`car_models` bigint(21)
,`spare_part_supplier_id` int(10) unsigned
);
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `list_of_values`
--

CREATE TABLE IF NOT EXISTS `list_of_values` (
  `lov_id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `lov_type` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`lov_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `price_parser_load_review`
--
CREATE TABLE IF NOT EXISTS `price_parser_load_review` (
`price_parser_run_id` int(10)
,`count(spp.spare_part_price_id)` bigint(21)
,`start` datetime
,`max(spp.created)` datetime
);
-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `price_parser_load_review_min`
--
CREATE TABLE IF NOT EXISTS `price_parser_load_review_min` (
`spare_part_supplier_id` int(10) unsigned
,`count(spp.spare_part_price_id)` bigint(21)
,`Minutes` varchar(16)
);
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `price_parser_runs`
--

CREATE TABLE IF NOT EXISTS `price_parser_runs` (
  `price_parser_run_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_base_name` varchar(255) COLLATE utf8_danish_ci DEFAULT NULL,
  `file_create_time` datetime DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `processing_start` datetime DEFAULT NULL,
  `processing_end` datetime DEFAULT NULL,
  `status` varchar(45) COLLATE utf8_danish_ci DEFAULT NULL,
  `last_elem_type` varchar(45) COLLATE utf8_danish_ci DEFAULT NULL,
  `last_elem_id` varchar(45) COLLATE utf8_danish_ci DEFAULT NULL,
  `created_by` varchar(45) COLLATE utf8_danish_ci DEFAULT NULL,
  `xml_http_request_id` int(10) DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`price_parser_run_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci AUTO_INCREMENT=45 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `spare_part_categories`
--

CREATE TABLE IF NOT EXISTS `spare_part_categories` (
  `spare_part_category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `spare_part_category_name` varchar(255) CHARACTER SET utf8  COLLATE utf8_danish_ci NOT NULL,
  `spare_part_category_description` varchar(4000) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `parent_spare_part_category_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `created_by` varchar(255) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `price_parser_run_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`spare_part_category_id`),
  UNIQUE KEY `spare_part_category_name` (`spare_part_category_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci AUTO_INCREMENT=30 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `spare_part_prices`
--

CREATE TABLE IF NOT EXISTS `spare_part_prices` (
  `spare_part_price_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(1024) COLLATE utf8_danish_ci NOT NULL,
  `description` varchar(1024) COLLATE utf8_danish_ci DEFAULT NULL,
  `spare_part_url` varchar(1024) CHARACTER SET utf8  COLLATE utf8_danish_ci NOT NULL,
  `spare_part_image_url` varchar(300) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL COMMENT 'This is an optional path to an image of the part',
  `spare_part_category_id` int(10) unsigned DEFAULT NULL,
  `spare_part_category_free_text` varchar(100) COLLATE utf8_danish_ci DEFAULT NULL COMMENT 'Shop part category - can be what ever',
  `part_placement` varchar(50) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `part_placement_left_right` enum('left','middle','right') CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `part_placement_front_back` enum('front','middle','back') CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `supplier_part_number` varchar(50) COLLATE utf8_danish_ci DEFAULT NULL,
  `original_part_number` varchar(50) COLLATE utf8_danish_ci DEFAULT NULL COMMENT 'Eg. Volvos part number',
  `price_inc_vat` decimal(15,2) NOT NULL,
  `producer_make_name` varchar(255) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL COMMENT 'Eg. Monroe',
  `producer_part_number` varchar(50) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `spare_part_supplier_id` int(10) unsigned NOT NULL COMMENT 'Reference to the Store',
  `created` datetime NOT NULL,
  `created_by` varchar(255) CHARACTER SET utf8  COLLATE utf8_danish_ci DEFAULT NULL,
  `price_parser_run_id` int(10) DEFAULT NULL,
  `xml_http_request_id` int(10) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`spare_part_price_id`),
  KEY `supplier_number` (`spare_part_supplier_id`,`supplier_part_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci AUTO_INCREMENT=417978 ;

-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `spare_part_prices_sup`
--
CREATE TABLE IF NOT EXISTS `spare_part_prices_sup` (
`supplier_name` varchar(255)
,`spare_part_price_id` int(10) unsigned
,`name` varchar(1024)
,`description` varchar(1024)
,`spare_part_url` varchar(1024)
,`spare_part_image_url` varchar(300)
,`spare_part_category_id` int(10) unsigned
,`spare_part_category_free_text` varchar(100)
,`part_placement` varchar(50)
,`part_placement_left_right` enum('left','middle','right')
,`part_placement_front_back` enum('front','middle','back')
,`supplier_part_number` varchar(50)
,`original_part_number` varchar(50)
,`price_inc_vat` decimal(15,2)
,`producer_make_name` varchar(255)
,`producer_part_number` varchar(50)
,`spare_part_supplier_id` int(10) unsigned
,`created` datetime
,`created_by` varchar(255)
,`updated` timestamp
,`state` enum('Aktiv','Prøve','Lukket')
);
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `spare_part_suppliers`
--

CREATE TABLE IF NOT EXISTS `spare_part_suppliers` (
  `updated_by` varchar(50) CHARACTER SET latin1 NOT NULL,
  `updated` time NOT NULL,
  `spare_part_supplier_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `supplier_url` varchar(255) CHARACTER SET latin1 NOT NULL,
  `supplier_product_catalog_url` varchar(255) CHARACTER SET latin1 NOT NULL,
  `supplier_admin_user_name` varchar(255) CHARACTER SET latin1 NOT NULL COMMENT 'must be unique',
  `supplier_admin_password` varchar(50) CHARACTER SET latin1 NOT NULL,
  `supplier_admin_email` varchar(50) CHARACTER SET latin1 NOT NULL,
  `state` enum('Aktiv','Prøve','Lukket') CHARACTER SET latin1 NOT NULL DEFAULT 'Aktiv',
  `supplier_secret_token` varchar(255) CHARACTER SET latin1 NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `xml_http_request_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`spare_part_supplier_id`),
  UNIQUE KEY `supplier_name` (`supplier_name`,`supplier_admin_user_name`),
  UNIQUE KEY `i_supplier_admin_user_name_uq` (`supplier_admin_user_name`(50))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Stand-in-struktur for visning `sps_spp_cm2spp_cmo_v`
--
CREATE TABLE IF NOT EXISTS `sps_spp_cm2spp_cmo_v` (
`supplier_name` varchar(255)
,`car_make_name` varchar(255)
,`car_model_name` varchar(255)
,`car_model_id` int(10) unsigned
,`spare_part_price_id` int(10) unsigned
,`name` varchar(1024)
,`description` varchar(1024)
,`spare_part_url` varchar(1024)
,`spare_part_image_url` varchar(300)
,`spare_part_category_id` int(10) unsigned
,`spare_part_category_free_text` varchar(100)
,`part_placement` varchar(50)
,`part_placement_left_right` enum('left','middle','right')
,`part_placement_front_back` enum('front','middle','back')
,`supplier_part_number` varchar(50)
,`original_part_number` varchar(50)
,`price_inc_vat` decimal(15,2)
,`producer_make_name` varchar(255)
,`producer_part_number` varchar(50)
,`spare_part_supplier_id` int(10) unsigned
,`year_from` int(4) unsigned
,`month_from` int(11)
,`year_to` int(4) unsigned
,`month_to` int(11)
,`chassis_no_from` varchar(17)
,`chassis_no_to` varchar(17)
);
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `user_requests`
--

CREATE TABLE IF NOT EXISTS `user_requests` (
  `user_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_info` varchar(200) COLLATE utf8_danish_ci DEFAULT NULL,
  `client_ip` varchar(20) COLLATE utf8_danish_ci NOT NULL,
  `url` varchar(200) COLLATE utf8_danish_ci DEFAULT NULL,
  `request_vars` varchar(45) COLLATE utf8_danish_ci DEFAULT NULL,
  `browser` varchar(100) COLLATE utf8_danish_ci DEFAULT NULL,
  `os` varchar(100) COLLATE utf8_danish_ci DEFAULT NULL,
  `request_time_taken_ms` double DEFAULT NULL,
  `rows_returned` int(11) DEFAULT NULL,
  `sql_used` varchar(4000) COLLATE utf8_danish_ci DEFAULT NULL,
  `q` varchar(400) COLLATE utf8_danish_ci DEFAULT NULL,
  `car_model_id` int(11) DEFAULT NULL,
  `car_model_name` varchar(45) COLLATE utf8_danish_ci DEFAULT NULL,
  `car_make_name` varchar(45) COLLATE utf8_danish_ci DEFAULT NULL,
  `car_make_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_request_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `xml_http_request`
--

CREATE TABLE IF NOT EXISTS `xml_http_request` (
  `xml_http_request_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_by` varchar(50) DEFAULT NULL,
  `request_payload` longtext,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `first_response` longtext,
  `latest_response` longtext,
  `server_request_uri` varchar(10000) CHARACTER SET utf8 COLLATE utf8_danish_ci DEFAULT NULL COMMENT 'Large to handle debugger urls',
  `unit_test_name` varchar(255) DEFAULT NULL,
  `unit_test_description` longtext,
  `user_info` varchar(100) DEFAULT NULL,
  `client_ip` varchar(16) DEFAULT NULL,
  `user_agent` varchar(1000) DEFAULT NULL,
  `http_cookie` varchar(1000) DEFAULT NULL,
  `request_time_taken_ms` int(11) DEFAULT NULL,
  `data_rows_returned` int(11) DEFAULT NULL,
  `sql_used` varchar(1000) DEFAULT NULL,
  `q` varchar(100) DEFAULT NULL,
  `car_model_id` int(11) DEFAULT NULL,
  `car_make_id` int(11) DEFAULT NULL,
  `trace` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`xml_http_request_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23271 ;

-- --------------------------------------------------------

--
-- Struktur for visning `car_makes_v`
--
DROP TABLE IF EXISTS `car_makes_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `car_makes_v` AS select `car_makes`.`car_make_id` AS `car_make_id`,`car_makes`.`car_make_name` AS `car_make_name` from `car_makes` where (`car_makes`.`state` in ('Offentlig','Foreslag')) order by `car_makes`.`car_make_name`;

-- --------------------------------------------------------

--
-- Struktur for visning `car_model_v`
--
DROP TABLE IF EXISTS `car_model_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `car_model_v` AS select `cma`.`car_make_name` AS `car_make_name`,`cmo`.`car_model_id` AS `car_model_id`,`cmo`.`car_make_id` AS `car_make_id`,`cmo`.`car_model_name` AS `car_model_name`,`cmo`.`car_model_main_id` AS `car_model_main_id`,`cmo`.`created` AS `created`,`cmo`.`created_by` AS `created_by`,`cmo`.`updated` AS `updated`,`cmo`.`updated_by` AS `updated_by`,`cmo`.`state` AS `state`,`cmo`.`state_enum` AS `state_enum` from (`car_models` `cmo` join `car_makes` `cma` on((`cmo`.`car_make_id` = `cma`.`car_make_id`)));

-- --------------------------------------------------------

--
-- Struktur for visning `car_models_v`
--
DROP TABLE IF EXISTS `car_models_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `car_models_v` AS select `cma`.`car_make_name` AS `car_make_name`,`cmo`.`car_model_id` AS `car_model_id`,`cmo`.`car_model_name` AS `car_model_name` from (`car_models` `cmo` join `car_makes` `cma` on((`cmo`.`car_make_id` = `cma`.`car_make_id`)));

-- --------------------------------------------------------

--
-- Struktur for visning `info_spp_price_days_stat_v`
--
DROP TABLE IF EXISTS `info_spp_price_days_stat_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `info_spp_price_days_stat_v` AS select `sps`.`supplier_name` AS `supplier_name`,count(`spp`.`spare_part_price_id`) AS `price_count`,`spp`.`spare_part_supplier_id` AS `spare_part_supplier_id`,cast(`spp`.`updated` as date) AS `updated_date` from (`spare_part_prices` `spp` join `spare_part_suppliers` `sps` on((`spp`.`spare_part_supplier_id` = `sps`.`spare_part_supplier_id`))) group by `spp`.`spare_part_supplier_id`,cast(`spp`.`updated` as date);

-- --------------------------------------------------------

--
-- Struktur for visning `info_spp_price_stat_v`
--
DROP TABLE IF EXISTS `info_spp_price_stat_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `info_spp_price_stat_v` AS select `sps`.`supplier_name` AS `supplier_name`,count(`spp`.`spare_part_price_id`) AS `price_count`,`spp`.`spare_part_supplier_id` AS `spare_part_supplier_id`,min(`spp`.`updated`) AS `oldest`,max(`spp`.`updated`) AS `newest` from (`spare_part_prices` `spp` join `spare_part_suppliers` `sps` on((`spp`.`spare_part_supplier_id` = `sps`.`spare_part_supplier_id`))) group by `spp`.`spare_part_supplier_id`;

-- --------------------------------------------------------

--
-- Struktur for visning `info_spp_view_days_stat_v`
--
DROP TABLE IF EXISTS `info_spp_view_days_stat_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `info_spp_view_days_stat_v` AS select `spp`.`supplier_name` AS `supplier_name`,count(`spp`.`spare_part_price_id`) AS `price_count`,count(`spp`.`car_make_name`) AS `car_makes`,count(`spp`.`car_model_id`) AS `car_models`,`spp`.`spare_part_supplier_id` AS `spare_part_supplier_id` from `sps_spp_cm2spp_cmo_v` `spp` group by `spp`.`spare_part_supplier_id`;

-- --------------------------------------------------------

--
-- Struktur for visning `price_parser_load_review`
--
DROP TABLE IF EXISTS `price_parser_load_review`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `price_parser_load_review` AS select `spp`.`price_parser_run_id` AS `price_parser_run_id`,count(`spp`.`spare_part_price_id`) AS `count(spp.spare_part_price_id)`,min(`spp`.`created`) AS `start`,max(`spp`.`created`) AS `max(spp.created)` from `spare_part_prices` `spp` group by `spp`.`price_parser_run_id`;

-- --------------------------------------------------------

--
-- Struktur for visning `price_parser_load_review_min`
--
DROP TABLE IF EXISTS `price_parser_load_review_min`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `price_parser_load_review_min` AS select `spp`.`spare_part_supplier_id` AS `spare_part_supplier_id`,count(`spp`.`spare_part_price_id`) AS `count(spp.spare_part_price_id)`,date_format(`spp`.`created`,'%c-%d %H.%i') AS `Minutes` from `spare_part_prices` `spp` group by `spp`.`spare_part_supplier_id`,date_format(`spp`.`created`,'%c-%d %H.%i');

-- --------------------------------------------------------

--
-- Struktur for visning `spare_part_prices_sup`
--
DROP TABLE IF EXISTS `spare_part_prices_sup`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `spare_part_prices_sup` AS select `sps`.`supplier_name` AS `supplier_name`,`spp`.`spare_part_price_id` AS `spare_part_price_id`,`spp`.`name` AS `name`,`spp`.`description` AS `description`,`spp`.`spare_part_url` AS `spare_part_url`,`spp`.`spare_part_image_url` AS `spare_part_image_url`,`spp`.`spare_part_category_id` AS `spare_part_category_id`,`spp`.`spare_part_category_free_text` AS `spare_part_category_free_text`,`spp`.`part_placement` AS `part_placement`,`spp`.`part_placement_left_right` AS `part_placement_left_right`,`spp`.`part_placement_front_back` AS `part_placement_front_back`,`spp`.`supplier_part_number` AS `supplier_part_number`,`spp`.`original_part_number` AS `original_part_number`,`spp`.`price_inc_vat` AS `price_inc_vat`,`spp`.`producer_make_name` AS `producer_make_name`,`spp`.`producer_part_number` AS `producer_part_number`,`spp`.`spare_part_supplier_id` AS `spare_part_supplier_id`,`spp`.`created` AS `created`,`spp`.`created_by` AS `created_by`,`spp`.`updated` AS `updated`,`sps`.`state` AS `state` from (`spare_part_prices` `spp` left join `spare_part_suppliers` `sps` on((`sps`.`spare_part_supplier_id` = `spp`.`spare_part_supplier_id`)));

-- --------------------------------------------------------

--
-- Struktur for visning `sps_spp_cm2spp_cmo_v`
--
DROP TABLE IF EXISTS `sps_spp_cm2spp_cmo_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sps_spp_cm2spp_cmo_v` AS select `sps`.`supplier_name` AS `supplier_name`,`cmo`.`car_make_name` AS `car_make_name`,`cmo`.`car_model_name` AS `car_model_name`,`cmo`.`car_model_id` AS `car_model_id`,`spp`.`spare_part_price_id` AS `spare_part_price_id`,`spp`.`name` AS `name`,`spp`.`description` AS `description`,`spp`.`spare_part_url` AS `spare_part_url`,`spp`.`spare_part_image_url` AS `spare_part_image_url`,`spp`.`spare_part_category_id` AS `spare_part_category_id`,`spp`.`spare_part_category_free_text` AS `spare_part_category_free_text`,`spp`.`part_placement` AS `part_placement`,`spp`.`part_placement_left_right` AS `part_placement_left_right`,`spp`.`part_placement_front_back` AS `part_placement_front_back`,`spp`.`supplier_part_number` AS `supplier_part_number`,`spp`.`original_part_number` AS `original_part_number`,`spp`.`price_inc_vat` AS `price_inc_vat`,`spp`.`producer_make_name` AS `producer_make_name`,`spp`.`producer_part_number` AS `producer_part_number`,`spp`.`spare_part_supplier_id` AS `spare_part_supplier_id`,`cm2spp`.`year_from` AS `year_from`,`cm2spp`.`month_from` AS `month_from`,`cm2spp`.`year_to` AS `year_to`,`cm2spp`.`month_to` AS `month_to`,`cm2spp`.`chassis_no_from` AS `chassis_no_from`,`cm2spp`.`chassis_no_to` AS `chassis_no_to` from (((`spare_part_prices` `spp` left join `spare_part_suppliers` `sps` on((`sps`.`spare_part_supplier_id` = `spp`.`spare_part_supplier_id`))) left join `car_models_to_spare_part_prices` `cm2spp` on((`spp`.`spare_part_price_id` = `cm2spp`.`spare_part_price_id`))) left join `car_models_v` `cmo` on((`cm2spp`.`car_model_id` = `cmo`.`car_model_id`)));
