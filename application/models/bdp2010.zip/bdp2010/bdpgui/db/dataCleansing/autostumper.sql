
select replace(substring(s.supplier_part_number,14),'Â ','') as vn, s.*
from spare_part_prices s
where s.supplier_part_number like 'Varenumm%';

update spare_part_prices 
set supplier_part_number = replace(substring(supplier_part_number,14),'Â ','')
where supplier_part_number like 'Varenumm%';

SET NAMES utf8;
SET CHARACTER SET utf8;

select *
from spare_part_prices;

--where supplier_part_number like 'Q00037';



delete 
from spare_part_prices;