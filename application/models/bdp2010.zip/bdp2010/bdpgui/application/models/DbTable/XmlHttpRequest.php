<?php

// application/models/DbTable/CarMakes.php

/**
 * This is the DbTable class for the guestbook table.
 */
class Default_Model_DbTable_XmlHttpRequest extends Zend_Db_Table_Abstract
{
    /** Table name */
    protected $_name    = 'xml_http_request';
    protected $_primary = 'xml_http_request_id';
}


?>