<?php

// application/models/DbTable/CarMakes.php

/**
 * This is the DbTable class for the guestbook table.
 */
class Default_Model_DbTable_PriceParserRuns extends Default_Model_DynBase
{
    /** Table name */
    protected $_name    = 'price_parser_runs';
    protected $_primary = 'price_parser_run_id';
}


?>