<?php

// application/models/DbTable/CarMakes.php

/**
 * This is the DbTable class for the guestbook table.
 */
class Default_Model_DbTable_CarModelsToSparePartPrices extends Zend_Db_Table_Abstract
{
    /** Table name */
    protected $_name    = 'car_models_to_spare_part_prices';
    //protected $_primary = array('car_make_id';/7CarModelsToSparePartPrices
}
