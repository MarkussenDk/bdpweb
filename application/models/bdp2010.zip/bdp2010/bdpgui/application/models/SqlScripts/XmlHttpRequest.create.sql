-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- V�rt: localhost
-- Genereringstid: 21. 09 2009 kl. 21:37:51
-- Serverversion: 5.1.36
-- PHP-version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `bdp_dev`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `xml_http_request`
--

CREATE TABLE IF NOT EXISTS `xml_http_request` (
  `xml_http_request_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_by` varchar(50) NOT NULL,
  `request_payload` longtext NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `first_response` longtext NOT NULL,
  `server_request_uri` VARCHAR( 255 ) NOT NULL,
  PRIMARY KEY (`xml_http_request_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Data dump for tabellen `xml_http_request`
--

