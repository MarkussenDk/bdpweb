<?php

/**
 * {0}
 * 
 * @author
 * @version 
 */
	
require_once 'Zend/Controller/Action.php';

class DojoController extends Zend_Controller_Action
{
	/**
	 * The default action - show the home page
	 */
    public function indexAction() 
    {
        // TODO Auto-generated {0}::indexAction() default action
    }
    
}

