<?php

require_once ('Zend\Dojo\Form.php');

/** 
 * @author Andreas
 * 
 * 
 */
class DojoUser extends Zend_Dojo_Form {
	//TODO - Insert your code here
	

	/**
	 * 
	 * @param   array|Zend_Config|null $options
 
	 * @return  void
      
	 */
	public function __construct($options = null) {
		parent::__construct ( $options = null );
		//TODO - Insert your code here
	}
}

?>